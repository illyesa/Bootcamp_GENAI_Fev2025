from utils import unzip_with_7z

zip_file_path = 'congrats.7z' # keep as is
dest_path = '.' # keep as is

find_me = '' # 2 letters are missing!
secret_password = find_me + 'bcmpda' 

# WRITE YOUR CODE BELOW
# ----------------------------------------

import string

def find_password():
    for a in string.ascii_lowercase:
        for b in string.ascii_lowercase:
            find_me = a + b
            secret_password = find_me + 'bcmpda'
            print(f"Trying password: {secret_password}")  # montrer le mot de passe en cours
            if unzip_with_7z(zip_file_path, dest_path, secret_password):
                print(f"Success! The password is: {secret_password}")
                return secret_password
    print("Password not found.")
    return None
find_password()